function Game0_0(){
}

function Game0(){
}

_ = Game0_0.prototype = Game0.prototype = new Object_0;
_.autoPlayButtonClicked_0 = function autoPlayButtonClicked(){
}
;
_.autoPlayEndedHandler_0 = function autoPlayEndedHandler(){
}
;
_.autoPlayStartedHandler_0 = function autoPlayStartedHandler(){
}
;
_.autoPlayToggleClose_0 = function autoPlayToggleClose(){
}
;
_.autoPlayToggleOpen_0 = function autoPlayToggleOpen(){
}
;
_.gameResourcesLoadCompleteHandler = function gameResourcesLoadCompleteHandler(resources){
}
;
_.getBgHeight_0 = function getBgHeight(){
  return 0;
}
;
_.getBgWidth_0 = function getBgWidth(){
  return 0;
}
;
_.getClass$ = function getClass_472(){
  return Lwebgl_client_nf_games_Game0_2_classLit;
}
;
_.getGameExternalResourcesList = function getGameExternalResourcesList(){
  return null;
}
;
_.getGameHeaderPanel = function getGameHeaderPanel(){
  return null;
}
;
_.getGameInfoMenuPanel = function getGameInfoMenuPanel(){
  return null;
}
;
_.getGameInfoMenuTitle = function getGameInfoMenuTitle(){
  return null;
}
;
_.getGameMainPanel = function getGameMainPanel(){
  return null;
}
;
_.getGameNonMandatoryResourcesList = function getGameNonMandatoryResourcesList(){
  return null;
}
;
_.getGamePreferredNonMandatoryResourcesList = function getGamePreferredNonMandatoryResourcesList(){
  return null;
}
;
_.getGameRotateResourcesList = function getGameRotateResourcesList(){
  return null;
}
;
_.getGameSettingsMenuPanel = function getGameSettingsMenuPanel(){
  return null;
}
;
_.getGameSettingsPanelTitle = function getGameSettingsPanelTitle(){
  return null;
}
;
_.getIsVerticalGame = function getIsVerticalGame(){
  return false;
}
;
_.initGame = function initGame(gamePanel, gameContainer, gameDO){
}
;
_.isAutoPlaySupported_0 = function isAutoPlaySupported(){
  return false;
}
;
_.isFreeGamesSupported = function isFreeGamesSupported(){
  return false;
}
;
_.isNotAutoPlaySupported = function isNotAutoPlaySupported(){
  return false;
}
;
_.isSoundsRequired = function isSoundsRequired(){
  return false;
}
;
_.optionsToggleOpen = function optionsToggleOpen(){
}
;
_.playGame_0 = function playGame(BTP){
}
;
_.resumeGame_0 = function resumeGame_0(){
}
;
_.setAutoplayAttachable = function setAutoplayAttachable(autoplayAttachable){
}
;
_.setBalance_0 = function setBalance_0(balance){
}
;
_.setGlobalMenuAttachable = function setGlobalMenuAttachable(globalMenuAttachable){
}
;
_.setHistoryDO = function setHistoryDO(historyStepDO){
}
;
_.setIsHistoryMode = function setIsHistoryMode(isHistoryMode){
}
;
_.shouldShowLogoInFullMenu = function shouldShowLogoInFullMenu(){
  return false;
}
;
_.stopGameOnError = function stopGameOnError(){
}
;
_ = GameManager$8.prototype;
_.onSuccess = function onSuccess(){
  var clientFactory;
  clientFactory = new Game0_0;
  this.this$0.game = clientFactory;
  $initGame_0(this.this$0);
}
;
var Lwebgl_client_nf_games_Game0_2_classLit = createForClass('webgl.client.nf.games.', 'Game0');
$entry(onLoad)(1);
