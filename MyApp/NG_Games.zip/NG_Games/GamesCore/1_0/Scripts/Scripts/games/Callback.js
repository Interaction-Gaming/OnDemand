﻿
function Cashier() {
   alert("Cashier Pressed");
}

function SwitchToMoney() {
	alert("Switch to money Pressed"); 
}

function Chat() {
	alert("Chat Pressed");
}

function ContactUs() {
	alert("ContactUS Pressed");
}

function Logout() {
	alert("Logout Pressed");
}

function HostingSystemAPIError(errorCode , errorMessage) {
	alert("HostingSystemAPIError: " + errorCode + ": " + errorMessage);
}
function NGSystemError(errorCode , errorMessage) {
	alert("NGSystemError: " + errorCode + ": " + errorMessage);
}