var loc = loc || {}; 
 loc.res_BigWinPopup_Loc={BigWinPopup_mc:{PopupContent_mc:{TextAmountAnim_mc:{tf:{w:463.95,h:115.7,x:-19.95,y:-18.2}},TextAnim1_mc:{},TextAnim_mc:{},ParticlesContainer_mc:{}}}};