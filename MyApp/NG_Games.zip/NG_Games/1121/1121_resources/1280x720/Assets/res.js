!function (e, n) {
    var a = e.animate.MovieClip, i = e.Container;
    n.BubbleParticle_mc = i.e(function () {
        i.call(this);
    }), n.res_1100_Splash_mc = i.e(function () {
        i.call(this);
    }), n.res_1100_res_561_ToolbarContainer_mc = i.e(function () {
        i.call(this);
    }), n.res_1100_InfoPopupContainer_mc = i.e(function () {
        i.call(this);
    }), n.res_1100_FreeGamesContainer_mc = i.e(function () {
        i.call(this);
    }), n.res_1100_MainGameContainer_mc = i.e(function () {
        i.call(this);
    }), n.res_1100_BonusGameContainer_mc = i.e(function () {
        i.call(this);
    }), (n.res = a.e(function () {
        a.call(this, 0, 1, !0, 24);
        var e = (new n.res_1100_BonusGameContainer_mc).t(0);
        this[e.name = 'BonusGameContainer_mc'] = e;
        var i = (new n.res_1100_MainGameContainer_mc).t(0);
        this[i.name = 'MainGameContainer_mc'] = i;
        var t = (new n.res_1100_FreeGamesContainer_mc).t(0);
        this[t.name = 'FreeGamesContainer_mc'] = t;
        var r = new n.res_1100_InfoPopupContainer_mc;
        this[r.name = 'InfoPopupContainer_mc'] = r;
        var _ = (new n.res_1100_res_561_ToolbarContainer_mc).t(0);
        this[_.name = 'ToolbarContainer_mc'] = _;
        var s = new n.res_1100_Splash_mc;
        this[s.name = 'Splash_mc'] = s;
        var c = (new n.BubbleParticle_mc).t(555, 317);
        this[c.name = 'BubbleParticle_mc'] = c, this.ac(e, i, t, r, _, s, c);
    })).assets = {};
}(PIXI, lib = lib || {});
var lib;